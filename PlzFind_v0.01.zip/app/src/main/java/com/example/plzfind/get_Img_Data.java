package com.example.plzfind;

public class get_Img_Data extends MainActivity{


}
